
public class Villager {

	String help="Brave warrior we need your aid a dragon has been terrorizng out village for awhile now,can you help us be rid of the beast?";
public void help(String help) {
	this.help=help;
}
}
