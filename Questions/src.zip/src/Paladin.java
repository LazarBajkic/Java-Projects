
public class Paladin {

	int attack2=30;
	int speed2=15;
	int defence2=50;
	int health2=100;
	public void Stats2(int speed2,int attack2,int defence2,int health2) {
		this.attack2=attack2;
		this.defence2=defence2;
		this.health2=health2;
		this.speed2=speed2;
	}
}
