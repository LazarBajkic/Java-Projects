
public class Rogue {
	
	
	int attack1=20;
	int speed1=25;
	int defence1=15;
	int health1=50;
	public void Stats1(int speed1,int attack1,int defence1,int health1) {
		this.attack1=attack1;
		this.defence1=defence1;
		this.health1=health1;
		this.speed1=speed1;
	}

}
