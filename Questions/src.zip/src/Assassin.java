
public class Assassin {

	int attack3=45;
	int speed3=50;
	int defence3=30;
	int health3=70;
	public void Stats3(int speed3,int attack3,int defence3,int health3) {
		this.attack3=attack3;
		this.defence3=defence3;
		this.health3=health3;
		this.speed3=speed3;
	}
}
