
public class Mage  {

	int attack4=35;
	int speed4=40;
	int defence4=25;
	int health4=60;
	public void Stats4(int speed4,int attack4,int defence4,int health4) {
		this.attack4=attack4;
		this.defence4=defence4;
		this.health4=health4;
		this.speed4=speed4;
	}
}
