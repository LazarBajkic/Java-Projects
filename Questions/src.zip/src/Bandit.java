
public class Bandit {
   
	String speak="this really isn't your lucky day pal";
	public void speak(String speak) {
		this.speak=speak;
	}
}
