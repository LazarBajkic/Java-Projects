
public interface Flee {

	void miss();
}
