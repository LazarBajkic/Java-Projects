
public interface Fight {

	void attack();
		
}
